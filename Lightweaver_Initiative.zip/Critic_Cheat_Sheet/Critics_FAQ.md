# Critics Cheat Sheet & FAQ

