# Initial Concepts and Notes

