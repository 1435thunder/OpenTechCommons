bl_info = {
    "name": "Scene Director",
    "blender": (3, 0, 0),
    "category": "Scene",
    "version": (0, 3, 0),
    "author": "OpenTechCommons x ChatGPT"
}

# Placeholder: Full add-on code will go here
# Scene Director v0.3: modular film scene management
