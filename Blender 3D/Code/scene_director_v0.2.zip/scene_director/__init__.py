bl_info = {
    "name": "Scene Director",
    "author": "Boss + ChatGPT",
    "version": (0, 2),
    "blender": (2, 93, 0),
    "location": "View3D > Sidebar > Scene Director",
    "description": "Manage scenes, takes, notes, and markdown previews inside Blender",
    "category": "Production",
}

import bpy
from . import panel

def register():
    panel.register()

def unregister():
    panel.unregister()

if __name__ == "__main__":
    register()
