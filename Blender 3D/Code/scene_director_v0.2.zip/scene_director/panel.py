import bpy
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import StringProperty, IntProperty, PointerProperty
import os

class SCENE_PT_director_panel(Panel):
    bl_label = "🎬 Scene Director"
    bl_idname = "SCENE_PT_director_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Scene Director"

    def draw(self, context):
        layout = self.layout
        scene = context.scene.scene_director_props

        layout.label(text="Create New Scene Structure:")
        layout.prop(scene, "film_name")
        layout.prop(scene, "scene_number")
        layout.prop(scene, "scene_name")
        layout.prop(scene, "take_number")
        layout.operator("scene_director.create_scene", icon="FILE_NEW")

        layout.separator()
        layout.label(text="Scene Notes:")
        layout.prop(scene, "notes")
        layout.operator("scene_director.save_notes", icon="TEXT")

        layout.separator()
        layout.label(text="📄 Markdown Preview:")
        draw_markdown(layout, scene.notes)

        layout.separator()
        layout.prop(scene, "ref_image_path", text="📷 Reference Image")

def draw_markdown(layout, text):
    lines = text.splitlines()
    for line in lines:
        line = line.strip()
        if line.startswith("# "):
            layout.label(text=line[2:], icon="BOOKMARKS")
        elif line.startswith("## "):
            layout.label(text="  " + line[3:], icon="DOT")
        elif line.startswith("- "):
            layout.label(text="• " + line[2:], icon="BLANK1")
        elif "**" in line:
            layout.label(text=line.replace("**", ""), icon="INFO")
        elif "_" in line:
            layout.label(text=line.replace("_", ""), icon="INFO")
        else:
            layout.label(text=line)

class CreateSceneStructure(Operator):
    bl_idname = "scene_director.create_scene"
    bl_label = "Create Scene Folder"

    def execute(self, context):
        props = context.scene.scene_director_props
        base = bpy.path.abspath("//")
        film_dir = os.path.join(base, props.film_name)
        scene_folder = f"S{props.scene_number:02d}_{props.scene_name}"
        take_folder = f"T{props.take_number:02d}"
        full_path = os.path.join(film_dir, "scenes", scene_folder, "takes", take_folder)
        os.makedirs(full_path, exist_ok=True)
        self.report({'INFO'}, f"Created: {full_path}")
        return {'FINISHED'}

class SaveNotesOperator(Operator):
    bl_idname = "scene_director.save_notes"
    bl_label = "Save Notes"

    def execute(self, context):
        props = context.scene.scene_director_props
        base = bpy.path.abspath("//")
        scene_folder = f"S{props.scene_number:02d}_{props.scene_name}"
        take_folder = f"T{props.take_number:02d}"
        notes_path = os.path.join(base, props.film_name, "scenes", scene_folder, "takes", take_folder, "notes.txt")
        os.makedirs(os.path.dirname(notes_path), exist_ok=True)
        with open(notes_path, "w") as f:
            f.write(props.notes)
        self.report({'INFO'}, f"Notes saved to {notes_path}")
        return {'FINISHED'}

class SceneDirectorProperties(PropertyGroup):
    film_name: StringProperty(name="Film Name", default="MyFilm")
    scene_number: IntProperty(name="Scene #", default=1, min=1)
    scene_name: StringProperty(name="Scene Name", default="Intro")
    take_number: IntProperty(name="Take #", default=1, min=1)
    notes: StringProperty(name="Scene Notes", default="")
    ref_image_path: StringProperty(
        name="Reference Image Path",
        subtype='FILE_PATH',
        description="Path to the reference image"
    )

classes = (
    SCENE_PT_director_panel,
    CreateSceneStructure,
    SaveNotesOperator,
    SceneDirectorProperties,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.scene_director_props = PointerProperty(type=SceneDirectorProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.scene_director_props
